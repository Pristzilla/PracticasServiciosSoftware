package es.unican.ss.SSEstimacionParadasTUS;

public class DatosNoDisponiblesException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DatosNoDisponiblesException() {}

}
