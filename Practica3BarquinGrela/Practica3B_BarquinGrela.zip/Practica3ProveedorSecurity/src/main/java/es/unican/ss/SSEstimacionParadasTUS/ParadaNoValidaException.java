package es.unican.ss.SSEstimacionParadasTUS;

public class ParadaNoValidaException extends Exception {	


}
