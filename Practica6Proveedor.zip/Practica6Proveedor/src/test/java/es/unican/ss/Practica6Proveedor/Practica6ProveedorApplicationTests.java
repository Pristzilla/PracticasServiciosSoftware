package es.unican.ss.Practica6Proveedor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica6ProveedorApplicationTests {

	@Test
	void contextLoads() {
	}

}
