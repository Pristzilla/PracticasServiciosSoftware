package es.unican.ss.Practica6Proveedor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practica6ProveedorApplication {

	public static void main(String[] args) {
		SpringApplication.run(Practica6ProveedorApplication.class, args);
	}

}
