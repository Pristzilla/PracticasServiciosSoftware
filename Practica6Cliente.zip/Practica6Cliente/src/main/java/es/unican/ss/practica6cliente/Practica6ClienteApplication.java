package es.unican.ss.practica6cliente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practica6ClienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(Practica6ClienteApplication.class, args);
	}

}
