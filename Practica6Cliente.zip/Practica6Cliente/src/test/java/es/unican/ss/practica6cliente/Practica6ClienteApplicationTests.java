package es.unican.ss.practica6cliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica6ClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
